# Assignment 2

> Assignment 2 (Scalable Web Service with Golang - DTS Kominfo X Hacktiv8)
