package routers

import (
	"assignment-2/controllers"

	"github.com/gin-gonic/gin"
)

func StartServer(Cont *controllers.Controller) *gin.Engine {
	router := gin.Default()

	router.POST("/orders", Cont.CreateOrder)
	router.GET("/orders", Cont.GetOrders)
	router.PUT("/orders/:orderId", Cont.UpdateOrder)
	router.DELETE("/orders/:orderId", Cont.DeleteOrder)

	return router
}
